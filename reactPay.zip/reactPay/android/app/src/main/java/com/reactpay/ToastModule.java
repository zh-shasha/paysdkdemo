package com.reactpay;
// ToastModule.java


import android.util.Log;
import android.widget.Toast;

import com.lingk.pay.AliPayCallBackParams;
import com.lingk.pay.Alipay;
import com.lingk.pay.AlipayResultCallBack;

import com.lingk.pay.WXCallBackParams;
import com.lingk.pay.WXPay;
import com.lingk.pay.WXPayResultCallBack;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.Dynamic;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactBridge;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.modules.core.DeviceEventManagerModule;

import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ToastModule extends ReactContextBaseJavaModule {
    private static ReactApplicationContext reactContext;

    private static final String DURATION_SHORT_KEY = "SHORT";
    private static final String DURATION_LONG_KEY = "LONG";

    public ToastModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
    }

    @Override
    public String getName() {
        return "ToastExample";
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<>();
        constants.put(DURATION_SHORT_KEY, Toast.LENGTH_SHORT);
        constants.put(DURATION_LONG_KEY, Toast.LENGTH_LONG);
        return constants;
    }

    @ReactMethod
    public void show(String message, int duration) {
        Log.d("TEST", "show: 123123123SDFSDF");
        Toast.makeText(getReactApplicationContext(), message, duration).show();
    }

    void sendPayEvent(String message) {
        getReactApplicationContext()
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit("lk-pay-event", message);
    }

    //Alipay
    @ReactMethod
    public void onAlipay(String subject, Double price, String body) {

        Alipay.Pay(getCurrentActivity(), subject, price, body, new AlipayResultCallBack() {
            @Override
            public void onSuccess(AliPayCallBackParams callBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付成功", Toast.LENGTH_SHORT).show();
                sendPayEvent(getCallBackParams("success", callBackParams));
                System.out.println("支付成功Main");
            }

            @Override
            public void onBind(AliPayCallBackParams callBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付订单绑定", Toast.LENGTH_SHORT).show();
//                System.out.println("支付订单绑定:" + callBackParams.getTotalAmount() + callBackParams.getSubject() + callBackParams.getOrder() + callBackParams.getBody());
                sendPayEvent(getCallBackParams("bind", callBackParams));
            }

            @Override
            public void onDealing(AliPayCallBackParams callBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付处理中...", Toast.LENGTH_SHORT).show();
                sendPayEvent(getCallBackParams("dealing", callBackParams));

            }

            @Override
            public void onError(int error_code, AliPayCallBackParams callBackParams) {
                switch (error_code) {
                    case Alipay.ERROR_NETWORK:
                        Toast.makeText(getReactApplicationContext(), "支付失败:网络连接错误", Toast.LENGTH_SHORT).show();
                        sendPayEvent(getCallBackParams("error", callBackParams));

                        break;
                    case Alipay.ERROR_PAY:
                        Toast.makeText(getReactApplicationContext(), "支付错误:支付码支付失败", Toast.LENGTH_SHORT).show();
                        sendPayEvent(getCallBackParams("error", callBackParams));

                        break;
                    case Alipay.ERROR_ORDER_NETWORK:
                        Toast.makeText(getReactApplicationContext(), "下单接口连接失败" + "order:" + callBackParams.getBody(), Toast.LENGTH_SHORT).show();
                        sendPayEvent(getCallBackParams("error", callBackParams));

                        break;
                    default:
                        Toast.makeText(getReactApplicationContext(), "支付错误", Toast.LENGTH_SHORT).show();
                        sendPayEvent(getCallBackParams("error", callBackParams));
                        break;
                }
            }

            @Override
            public void onCancel(AliPayCallBackParams callBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付取消" + callBackParams.getOrder() + ":" + callBackParams.getTotalAmount(), Toast.LENGTH_SHORT).show();
                Log.e("AliPay", "支付取消：" + "subject:" + callBackParams.getSubject() + "order:" + callBackParams.getOrder() + "body:" + callBackParams.getBody() + ",mount:" + callBackParams.getTotalAmount());
                sendPayEvent(getCallBackParams("cancel", callBackParams));
            }
        });
    }
    @ReactMethod
    public void onWXPay(String subject, String price, String body){
        WXPay.Pay(getCurrentActivity(), subject, price, body, new WXPayResultCallBack() {
            @Override
            public void onSuccess(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付成功", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void Unpaid(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "未支付", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCancel(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付取消", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onRefund(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onPayClose(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付已关闭", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onDealing(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付处理中", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onError(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付失败", Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onWithHold(WXCallBackParams wxCallBackParams) {
                Toast.makeText(getReactApplicationContext(), "支付扣款中", Toast.LENGTH_SHORT).show();

            }
        });
    }

    static String getWXCallBackParams(String type, WXCallBackParams wxCallBackParams) {
        String callbackParams = "{}";
        try {
            JSONObject obj = new JSONObject();
            obj.put("type", type);
            obj.put("subject", wxCallBackParams.getSubject());
            obj.put("body", wxCallBackParams.getBody());
            obj.put("order", wxCallBackParams.getOrder());
            obj.put("totalAmount", wxCallBackParams.getTotalAmount());
            callbackParams = obj.toString();
        } catch (Exception e) {
            e.printStackTrace();
            callbackParams = "{}";
        }
        return callbackParams;
    }
    static String getCallBackParams(String type, AliPayCallBackParams aliPayCallBackParams) {
        String callbackParams = "{}";
        try {
            JSONObject obj = new JSONObject();
            obj.put("type", type);
            obj.put("subject", aliPayCallBackParams.getSubject());
            obj.put("body", aliPayCallBackParams.getBody());
            obj.put("order", aliPayCallBackParams.getOrder());
            obj.put("totalAmount", aliPayCallBackParams.getTotalAmount());
            callbackParams = obj.toString();
        } catch (Exception e) {
            e.printStackTrace();
            callbackParams = "{}";
        }
        return callbackParams;
    }
}
