/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

 import React from 'react';
 import {
   SafeAreaView,
   StyleSheet,
   ScrollView,
   View,
   Text,
   StatusBar,
   Button,
   DeviceEventEmitter
 
 } from 'react-native';
 
 import {
   Header,
   LearnMoreLinks,
   Colors,
   DebugInstructions,
   ReloadInstructions,
 } from 'react-native/Libraries/NewAppScreen';
 
 import { NativeModules } from "react-native";
 
 let ToastExample = NativeModules.ToastExample;
 console.log("ToastExample:", ToastExample);
 
 const App: () => React$Node = () => {
 
     React.useEffect(() => {
         //收到监听
         this.listener = DeviceEventEmitter.addListener('lk-pay-event',(message)=>{
           ToastExample.show("支付回调消息:" + message, ToastExample.SHORT);
           let params = JSON.parse(message);
           switch (params.type) {
             case "success":
                 console.log("支付成功了：" +message, ToastExample.SHORT);
               break;
             case "bind":
                 console.log("支付在这里绑定：" +message, ToastExample.SHORT);
               break;
             case "error":
                 console.log("支付错误了：" +message, ToastExample.SHORT);
 
               break;
             case "cancel":
                 console.log("支付取消了：" +message, ToastExample.SHORT);
 
               break;
             case "dealing":
                 console.log("支付进行中：" +message, ToastExample.SHORT);
 
               break;
             default:
               ;
           }
         });
     });
 
   const onToast = () => {
     ToastExample.show("Awesome Toast, 123456", ToastExample.SHORT);
   }
    
   const onPay1 = () => {
     ToastExample.onAlipay("red",0.01,"green");
   }
   const onPay2 = () => {
     ToastExample.onWXPay("apple", "0.01", "good");
   }
   const onCallBack = () => {
       ToastExample.callBackTest(function(code,message){
       let subject = message.subject;
       ToastExample.show("Awesome:"+code+subject, ToastExample.SHORT);
       });
     }
 
   return (
     <>
       <StatusBar barStyle="dark-content" />
       <SafeAreaView>
         <ScrollView
           contentInsetAdjustmentBehavior="automatic"
           style={styles.scrollView}>
           <Header />
           <View style={styles.body}>
     
             <View style={styles.sectionContainer}>
                 <Button
                   onPress={onToast}
                   title="Toast"
                   color="#841584"
                   accessibilityLabel="Learn more about this purple button"
                 />
             </View>
             <View style={styles.sectionContainer}>
                 <Button
                   onPress={onPay1}
                   title="Alipay"
                   color="#841584"
                   accessibilityLabel="Learn more about this purple button"
                 />
             </View>
 
             <View style={styles.sectionContainer}>
                 <Button
                   onPress={onPay2}
                   title="wechatPay"
                   color="#841584"
                   accessibilityLabel="Learn more about this purple button"
                 />
             </View>
             <View style={styles.sectionContainer}>
                             <Button
                               onPress={onCallBack}
                               title="CallBack"
                               color="#841584"
                               accessibilityLabel="Learn more about this purple button"
                             />
                         </View>
             <LearnMoreLinks />
           </View>
         </ScrollView>
       </SafeAreaView>
     </>
   );
 };
 
 const styles = StyleSheet.create({
   scrollView: {
     backgroundColor: Colors.lighter,
   },
   engine: {
     position: 'absolute',
     right: 0,
   },
   body: {
     backgroundColor: Colors.white,
   },
   sectionContainer: {
     marginTop: 32,
     paddingHorizontal: 24,
   },
   sectionTitle: {
     fontSize: 24,
     fontWeight: '600',
     color: Colors.black,
   },
   sectionDescription: {
     marginTop: 8,
     fontSize: 18,
     fontWeight: '400',
     color: Colors.dark,
   },
   highlight: {
     fontWeight: '700',
   },
   footer: {
     color: Colors.dark,
     fontSize: 12,
     fontWeight: '600',
     padding: 4,
     paddingRight: 12,
     textAlign: 'right',
   },
 });
 
 export default App;
 